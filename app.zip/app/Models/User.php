<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'avatar',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    // inside class User extends Authenticatable

/**
 * Safely return role name (supports Spatie or simple role column).
 */
public function displayRoleName(): ?string
{
    // If spatie trait exists
    if (method_exists($this, 'getRoleNames')) {
        return $this->getRoleNames()->first() ?: null;
    }

    // Fallback to role column
    return $this->role ?: null;
}

/**
 * Convenience check for admin (used in controllers/views)
 */
public function isAdmin(): bool
{
    if (method_exists($this, 'hasRole')) {
        return $this->hasRole('admin');
    }

    return strtolower((string) $this->role) === 'admin';
}

}
