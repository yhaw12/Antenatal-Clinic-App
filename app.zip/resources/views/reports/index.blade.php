@extends('layouts.app')

@section('title', 'Reports')
@section('page-title', 'Reports')

@section('content')
@php
  // Defensive defaults
  $from = $from ?? now()->format('Y-m-d');
  $to = $to ?? now()->format('Y-m-d');
  $status = $status ?? '';
  $kpis = $kpis ?? ['total' => 0, 'present' => 0, 'notArrived' => 0, 'new' => 0, 'review' => 0, 'referrals' => 0, 'cancelled' => 0];
  $chart = $chart ?? ['labels' => [], 'counts' => []];
  $callStats = $callStats ?? [];
  $comparison = $comparison ?? null;
  $appts = $appts ?? collect();
@endphp

<div class="min-h-screen py-4 sm:py-8 px-4 sm:px-6 bg-app text-body">
  
  <div class="max-w-7xl mx-auto space-y-6">

    {{-- Header & Toolbar --}}
    <div class="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
      <div>
        <h1 class="text-2xl font-extrabold text-body">Appointment Reports</h1>
        <p class="mt-1 text-sm text-muted">Analyze clinic performance, attendance, and workload.</p>
      </div>

      <div class="flex flex-col items-end gap-3 w-full lg:w-auto">
        
        {{-- Quick Filters (Scrollable on mobile) --}}
        <div class="w-full overflow-x-auto pb-2 lg:pb-0 lg:w-auto no-scrollbar">
            <div class="flex gap-2 min-w-max">
                <button type="button" onclick="setDateRange('{{ now()->startOfMonth()->toDateString() }}', '{{ now()->endOfMonth()->toDateString() }}')" class="text-xs px-3 py-1.5 rounded border border-border text-muted bg-surface hover:opacity-80 transition">This Month</button>
                <button type="button" onclick="setDateRange('{{ now()->subMonth()->startOfMonth()->toDateString() }}', '{{ now()->subMonth()->endOfMonth()->toDateString() }}')" class="text-xs px-3 py-1.5 rounded border border-border text-muted bg-surface hover:opacity-80 transition">Last Month</button>
                <button type="button" onclick="setDateRange('{{ now()->subDays(7)->toDateString() }}', '{{ now()->toDateString() }}')" class="text-xs px-3 py-1.5 rounded border border-border text-muted bg-surface hover:opacity-80 transition">Last 7 Days</button>
            </div>
        </div>

        <div class="w-full lg:w-auto">
          <form id="reportFilters" action="{{ route('reports.generate') }}" method="GET" class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div class="flex items-center gap-2 flex-1">
                <input type="date" name="from" value="{{ $from }}" class="w-full sm:w-auto h-10 px-3 rounded-lg text-sm shadow-sm focus:ring-2 focus:ring-brand border border-border bg-surface text-body"/>
                <span class="text-muted text-xs">to</span>
                <input type="date" name="to" value="{{ $to }}" class="w-full sm:w-auto h-10 px-3 rounded-lg text-sm shadow-sm focus:ring-2 focus:ring-brand border border-border bg-surface text-body"/>
            </div>
            
            <select name="status" class="h-10 px-3 rounded-lg text-sm shadow-sm focus:ring-2 focus:ring-brand border border-border bg-surface text-body cursor-pointer">
              <option value="" {{ $status === '' ? 'selected' : '' }}>All Status</option>
              <option value="scheduled" {{ $status === 'scheduled' ? 'selected' : '' }}>Scheduled</option>
              <option value="present" {{ $status === 'present' ? 'selected' : '' }}>Present</option>
              <option value="missed" {{ $status === 'missed' ? 'selected' : '' }}>Missed</option>
              <option value="cancelled" {{ $status === 'cancelled' ? 'selected' : '' }}>Cancelled</option>
            </select>

            <div class="flex gap-2">
                <button type="submit" class="flex-1 sm:flex-none inline-flex justify-center items-center gap-2 px-4 h-10 rounded-lg text-sm font-bold shadow hover:brightness-110 transition-all bg-brand text-white">
                  Generate
                </button>

                {{-- Export Dropdown --}}
                <div class="relative">
                  <button id="exportToggle" type="button" aria-expanded="false" class="h-10 px-3 rounded-lg text-sm font-bold shadow hover:brightness-110 transition-all bg-success text-white flex items-center justify-center">
                    <svg class="w-4 h-4 sm:mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    <span class="hidden sm:inline">Export</span>
                  </button>
                  <div id="exportMenu" class="hidden absolute right-0 mt-2 w-44 rounded-xl shadow-xl z-20 overflow-hidden bg-surface border border-border">
                    <form action="{{ route('exports.queue') }}" method="POST">
                      @csrf
                      <input type="hidden" name="from" value="{{ $from }}"><input type="hidden" name="to" value="{{ $to }}">
                      <button name="format" value="csv" class="w-full text-left px-4 py-3 text-sm hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-body">CSV (.csv)</button>
                      <button name="format" value="excel" class="w-full text-left px-4 py-3 text-sm hover:bg-black/5 dark:hover:bg-white/5 transition-colors border-t border-border text-body">Excel (.xlsx)</button>
                    </form>
                  </div>
                </div>
            </div>
          </form>
        </div>
      </div>
    </div>

    {{-- 1. Main KPI Cards --}}
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="p-5 rounded-2xl shadow-sm flex items-center gap-4 transition-transform hover:-translate-y-1 bg-surface border border-border">
        <div class="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style="background: color-mix(in srgb, var(--brand) 10%, transparent);">
          <svg class="w-6 h-6 text-brand" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
        </div>
        <div>
          <div class="text-xs uppercase font-bold tracking-wide text-muted">Total Appts</div>
          <div class="text-2xl font-black text-body">{{ number_format($kpis['total']) }}</div>
        </div>
      </div>

      <div class="p-5 rounded-2xl shadow-sm flex items-center gap-4 transition-transform hover:-translate-y-1 bg-surface border border-border">
        <div class="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style="background: color-mix(in srgb, var(--success) 10%, transparent);">
          <svg class="w-6 h-6 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <div>
          <div class="text-xs uppercase font-bold tracking-wide text-muted">Present</div>
          <div class="text-2xl font-black text-body">{{ number_format($kpis['present']) }}</div>
        </div>
      </div>

      <div class="p-5 rounded-2xl shadow-sm flex items-center gap-4 transition-transform hover:-translate-y-1 bg-surface border border-border">
        <div class="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style="background: color-mix(in srgb, var(--accent) 10%, transparent);">
          <svg class="w-6 h-6 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
        </div>
        <div>
          <div class="text-xs uppercase font-bold tracking-wide text-muted">Attendance Rate</div>
          @php $rate = ($kpis['total'] > 0) ? round(($kpis['present'] / $kpis['total']) * 100, 1) : 0; @endphp
          <div class="text-2xl font-black text-body">{{ $rate }}<span class="text-sm font-medium text-muted">%</span></div>
        </div>
      </div>

      <div class="p-5 rounded-2xl shadow-sm flex items-center gap-4 transition-transform hover:-translate-y-1 bg-surface border border-border">
        <div class="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style="background: color-mix(in srgb, var(--danger) 10%, transparent);">
          <svg class="w-6 h-6 text-danger" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <div>
          <div class="text-xs uppercase font-bold tracking-wide text-muted">Missed</div>
          <div class="text-2xl font-black text-body">{{ number_format($kpis['notArrived']) }}</div>
        </div>
      </div>
    </div>

    {{-- 2. Daily Trends Chart --}}
    <div class="rounded-2xl p-4 sm:p-6 shadow-sm bg-surface border border-border">
      <h3 class="text-sm font-bold mb-4 text-body">Daily Appointments Trend</h3>
      @if(empty($chart['labels']) && !$comparison)
        <div class="text-center py-12 text-muted">No data available for this range.</div>
      @else
        <div class="relative h-64 w-full">
            <canvas id="appointmentChart"></canvas>
        </div>
      @endif
    </div>

    {{-- 3. Insights Row (Clinical Flow & Call Stats) --}}
    @if(!$comparison)
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        <div class="rounded-2xl p-4 sm:p-6 shadow-sm bg-surface border border-border">
            <h3 class="text-sm font-bold mb-6 flex items-center gap-2 text-body">
                <svg class="w-4 h-4 text-brand" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 01-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                Clinical Flow
            </h3>
            <div class="flex flex-col sm:flex-row items-center sm:items-start gap-8">
                <div class="w-32 h-32 relative shrink-0">
                    <canvas id="workloadChart"></canvas>
                    <div class="absolute inset-0 flex items-center justify-center flex-col pointer-events-none">
                        <span class="text-2xl font-bold text-body">{{ $kpis['total'] }}</span>
                        <span class="text-[10px] uppercase text-muted">Patients</span>
                    </div>
                </div>

                <div class="flex-1 grid grid-cols-2 gap-x-8 gap-y-4 w-full">
                    <div>
                        <div class="flex justify-between text-xs mb-1">
                            <span class="text-muted">New Cases</span>
                            <span class="font-bold text-brand">{{ $kpis['new'] ?? 0 }}</span>
                        </div>
                        <div class="w-full h-1.5 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
                            <div class="h-full rounded-full bg-brand" style="width: {{ $kpis['total'] ? ($kpis['new']/$kpis['total'])*100 : 0 }}%"></div>
                        </div>
                    </div>

                    <div>
                        <div class="flex justify-between text-xs mb-1">
                            <span class="text-muted">Reviews</span>
                            <span class="font-bold text-success">{{ $kpis['review'] ?? 0 }}</span>
                        </div>
                        <div class="w-full h-1.5 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
                            <div class="h-full rounded-full bg-success" style="width: {{ $kpis['total'] ? ($kpis['review']/$kpis['total'])*100 : 0 }}%"></div>
                        </div>
                    </div>

                    <div>
                        <div class="flex justify-between text-xs mb-1">
                            <span class="text-muted">Referrals Sent</span>
                            <span class="font-bold text-accent">{{ $kpis['referrals'] ?? 0 }}</span>
                        </div>
                        <div class="w-full h-1.5 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
                            <div class="h-full rounded-full bg-accent" style="width: {{ $kpis['present'] ? ($kpis['referrals']/$kpis['present'])*100 : 0 }}%"></div>
                        </div>
                    </div>

                    <div>
                        <div class="flex justify-between text-xs mb-1">
                            <span class="text-muted">Cancelled</span>
                            <span class="font-bold text-danger">{{ $kpis['cancelled'] ?? 0 }}</span>
                        </div>
                        <div class="w-full h-1.5 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
                            <div class="h-full rounded-full bg-danger" style="width: {{ $kpis['total'] ? ($kpis['cancelled']/$kpis['total'])*100 : 0 }}%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="rounded-2xl p-4 sm:p-6 shadow-sm bg-surface border border-border">
            <h3 class="text-sm font-bold mb-6 flex items-center gap-2 text-body">
                <svg class="w-4 h-4 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                Call Outcomes
            </h3>
            @if(empty($callStats))
                <div class="h-32 flex flex-col items-center justify-center text-sm text-muted">
                    <svg class="w-8 h-8 mb-2 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"/></svg>
                    No calls logged in this period
                </div>
            @else
                <div class="flex flex-col sm:flex-row items-center gap-8">
                    <div class="w-32 h-32 relative shrink-0">
                        <canvas id="callChart"></canvas>
                    </div>
                    <div class="flex-1 space-y-2 text-sm w-full">
                        @foreach($callStats as $res => $count)
                            <div class="flex justify-between items-center p-2 rounded hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                                <span class="capitalize text-muted">{{ str_replace('_', ' ', $res) }}</span>
                                <span class="font-bold px-2 py-0.5 rounded text-xs bg-bg border border-border text-body">{{ $count }}</span>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endif
        </div>
    </div>
    @endif

    {{-- 4. Detailed List / Table --}}
    <div class="rounded-2xl shadow-sm overflow-hidden bg-surface border border-border">
      <div class="px-4 sm:px-6 py-4 border-b border-border flex items-center justify-between">
          <h3 class="font-bold text-sm text-body">Detailed List</h3>
          <span class="text-xs px-2 py-1 rounded bg-bg text-muted">{{ $appts->total() }} records</span>
      </div>
      
      <div class="overflow-x-auto">
        <table class="min-w-full text-left text-sm whitespace-nowrap">
          <thead class="uppercase tracking-wider border-b border-border text-muted" style="background: color-mix(in srgb, var(--bg) 50%, transparent); font-size:11px;">
            <tr>
              <th class="px-4 sm:px-6 py-3 font-semibold">Date & Time</th>
              <th class="px-4 sm:px-6 py-3 font-semibold">Patient</th>
              <th class="px-4 sm:px-6 py-3 font-semibold">Status</th>
              <th class="px-4 sm:px-6 py-3 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-border">
            @forelse($appts as $appt)
              <tr class="hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                <td class="px-4 sm:px-6 py-3">
                  <div class="font-medium text-body">{{ \Carbon\Carbon::parse($appt->date)->format('M d, Y') }}</div>
                  <div class="text-xs text-muted">{{ $appt->time ? \Carbon\Carbon::parse($appt->time)->format('h:i A') : 'TBD' }}</div>
                </td>
                <td class="px-4 sm:px-6 py-3">
                  <div class="font-medium text-body">{{ optional($appt->patient)->first_name ?? 'Unknown' }} {{ optional($appt->patient)->last_name }}</div>
                  <div class="text-xs text-muted">{{ optional($appt->patient)->phone ?? 'No phone' }}</div>
                </td>
                <td class="px-4 sm:px-6 py-3">
                  @php $s = $appt->status ?? 'scheduled' @endphp
                  <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold capitalize" style="
                    background: {{ $s === 'missed' ? 'color-mix(in srgb, var(--danger) 10%, transparent)' : ($s === 'present' || $s === 'seen' ? 'color-mix(in srgb, var(--success) 10%, transparent)' : 'color-mix(in srgb, var(--brand) 10%, transparent)') }};
                    color: {{ $s === 'missed' ? 'var(--danger)' : ($s === 'present' || $s === 'seen' ? 'var(--success)' : 'var(--brand)') }};
                  ">
                    {{ $s }}
                  </span>
                </td>
                <td class="px-4 sm:px-6 py-3 text-right">
                  <a href="{{ route('patients.show', optional($appt->patient)->id) }}" class="text-brand hover:underline text-xs font-medium">View Profile</a>
                </td>
              </tr>
            @empty
              <tr>
                <td colspan="4" class="px-6 py-12 text-center text-muted">No appointments found.</td>
              </tr>
            @endforelse
          </tbody>
        </table>
      </div>
      
      @if($appts->hasPages())
      <div class="px-4 sm:px-6 py-4 border-t flex items-center justify-between" style="border-color:var(--border)">
          <div class="text-xs text-muted">
              Showing 
              <span class="font-bold text-body">{{ $appts->firstItem() ?? 0 }}</span> 
              to 
              <span class="font-bold text-body">{{ $appts->lastItem() ?? 0 }}</span> 
              of 
              <span class="font-bold text-body">{{ $appts->total() }}</span> 
              results
          </div>

          <div class="flex items-center gap-2">
              @if ($appts->onFirstPage())
                  <span class="px-3 py-1.5 text-xs font-medium rounded-lg border cursor-not-allowed bg-gray-50 border-border text-muted opacity-50">
                      Previous
                  </span>
              @else
                  <a href="{{ $appts->appends(request()->query())->previousPageUrl() }}" 
                     class="px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors shadow-sm bg-surface border-border text-body hover:bg-gray-50 dark:hover:bg-white/5">
                      Previous
                  </a>
              @endif

              @if ($appts->hasMorePages())
                  <a href="{{ $appts->appends(request()->query())->nextPageUrl() }}" 
                     class="px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors shadow-sm bg-surface border-border text-body hover:bg-gray-50 dark:hover:bg-white/5">
                      Next
                  </a>
              @else
                  <span class="px-3 py-1.5 text-xs font-medium rounded-lg border cursor-not-allowed bg-gray-50 border-border text-muted opacity-50">
                      Next
                  </span>
              @endif
          </div>
      </div>
      @endif
    </div>

  </div>
</div>

{{-- Scripts --}}
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@push('scripts')
<script>
  // Quick Filter Logic
  function setDateRange(start, end) {
      document.querySelector('input[name="from"]').value = start;
      document.querySelector('input[name="to"]').value = end;
      document.getElementById('reportFilters').submit();
  }

  // Export Menu Toggle
  document.addEventListener('DOMContentLoaded', () => {
    const exportToggle = document.getElementById('exportToggle');
    const exportMenu = document.getElementById('exportMenu');
    if (exportToggle && exportMenu) {
      exportToggle.addEventListener('click', (e) => {
          e.stopPropagation();
          exportMenu.classList.toggle('hidden');
      });
      document.addEventListener('click', (e) => {
        if (!exportMenu.contains(e.target) && !exportToggle.contains(e.target)) {
          exportMenu.classList.add('hidden');
        }
      });
    }
  });

  // Chart Rendering
  (function () {
    const cssVar = (name, fallback) => {
      const val = getComputedStyle(document.documentElement).getPropertyValue(name);
      return val ? val.trim() : fallback;
    };

    // 1. Main Line Chart (Daily Trend)
    const lineCtx = document.getElementById('appointmentChart')?.getContext('2d');
    const lineData = {!! json_encode($chart) !!};
    if (lineCtx && lineData.labels.length) {
      new Chart(lineCtx, {
        type: 'line',
        data: {
          labels: lineData.labels,
          datasets: [{
            label: 'Appointments',
            data: lineData.counts,
            borderColor: cssVar('--brand', '#3b82f6'),
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            fill: true,
            tension: 0.3,
            pointRadius: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: { y: { beginAtZero: true, grid: { borderDash: [2, 4] } }, x: { grid: { display: false } } }
        }
      });
    }

    // 2. Workload Doughnut (New vs Review)
    const workloadCtx = document.getElementById('workloadChart')?.getContext('2d');
    if (workloadCtx) {
        new Chart(workloadCtx, {
            type: 'doughnut',
            data: {
                labels: ['New', 'Review'],
                datasets: [{
                    data: [{{ $kpis['new'] ?? 0 }}, {{ $kpis['review'] ?? 0 }}],
                    backgroundColor: [cssVar('--brand', '#3b82f6'), cssVar('--success', '#10b981')],
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: { 
                responsive: true, 
                maintainAspectRatio: false, 
                plugins: { legend: { display: false } }, 
                cutout: '75%' 
            }
        });
    }

    // 3. Call Stats Doughnut
    const callCtx = document.getElementById('callChart')?.getContext('2d');
    if (callCtx) {
        const callData = {!! json_encode($callStats) !!};
        const labels = Object.keys(callData).map(s => s.replace(/_/g, ' '));
        const data = Object.values(callData);
        
        new Chart(callCtx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: ['#10b981', '#ef4444', '#f59e0b', '#3b82f6', '#6b7280'],
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: { 
                responsive: true, 
                maintainAspectRatio: false, 
                plugins: { legend: { display: false } }, 
                cutout: '75%' 
            }
        });
    }
  })();
</script>
@endpush
@endsection